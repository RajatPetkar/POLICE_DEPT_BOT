from flask import Flask, render_template, request, jsonify
import google.generativeai as genai
from langchain_core.messages import HumanMessage
from langchain_google_genai import ChatGoogleGenerativeAI
from werkzeug.utils import secure_filename
import os
import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import certifi

context = ssl.create_default_context(cafile=certifi.where())
app = Flask(__name__)

GOOGLE_API_KEY = "AIzaSyDSIlhQTswIhHENh-CdRWwe96gwwJ6Wz08"
genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel(model_name="gemini-pro")
llm = ChatGoogleGenerativeAI(model="gemini-pro-vision",google_api_key=GOOGLE_API_KEY)

@app.route('/')
def index():
    return render_template('index.html') 

@app.route('/index1')
def index1():
    return render_template('index1.html')


def send_email(receiver_email, subject, body):
    sender_email = "rajatpetkar250@gmail.com"  # Your email
    password = "gsvd vlro pvdn gful"  # Your email password

 # Create message container
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject


    # Attach body to the email
    msg.attach(MIMEText(body, 'plain'))
    

    try:
        # Create a secure SSL context
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.check_hostname = False

        # Connect to the SMTP server
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
            print("Email sent successfully!")
    except Exception as e:
        print(f"Error sending email: {str(e)}")
        
        
@app.route('/query', methods=['POST'])
def process_query():
    if request.method == 'POST':
        try:
            question = request.form['query'].strip()
            
            if question.lower() == 'fire':
                send_email("rajatpetkar665@gmail.com","FIR Fired Successfully", "The FIR has been fired successfully.")
                return "Email sent successfully"

            else:
                response = model.generate_content(question)
            
            return response.text

        except Exception as e:
            return str(e)

if __name__ == '__main__':
    app.run(debug=True)