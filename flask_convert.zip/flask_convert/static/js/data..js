const response = 
      [
        {
          "Question": "What is the purpose of a power transformer in a substation?",
          "Answer": "The primary purpose of a power transformer is to step up or step down voltage for efficient transmission and distribution of electrical power."
        },
        {
          "Question": "How does a transformer work?",
          "Answer": "Transformers work on the principle of electromagnetic induction, where varying current in one coil induces a voltage in another coil through a magnetic field."
        },
        {
          "Question": "What is the significance of the transformer's nameplate information?",
          "Answer": "The nameplate provides crucial details like rated capacity, voltage, current, and cooling methods. It is essential for proper operation and maintenance."
        },
        {
          "Question": "How does a transformer work?",
          "Answer": "Transformers work on the principle of electromagnetic induction, where varying current in one coil induces a voltage in another coil through a magnetic field."
        },
        {
          "Question": "What is the significance of the transformer's nameplate information?",
          "Answer": "The nameplate provides crucial details like rated capacity, voltage, current, and cooling methods. It is essential for proper operation and maintenance."
        },
        {
          "Question": "How does a transformer work?",
          "Answer": "Transformers work on the principle of electromagnetic induction, where varying current in one coil induces a voltage in another coil through a magnetic field."
        },
        {
          "Question": "What is the significance of the transformer's nameplate information?",
          "Answer": "The nameplate provides crucial details like rated capacity, voltage, current, and cooling methods. It is essential for proper operation and maintenance."
        },
        {
          "Question": "How does a transformer work?",
          "Answer": "Transformers work on the principle of electromagnetic induction, where varying current in one coil induces a voltage in another coil through a magnetic field."
        },
        {
          "Question": "What is the significance of the transformer's nameplate information?",
          "Answer": "The nameplate provides crucial details like rated capacity, voltage, current, and cooling methods. It is essential for proper operation and maintenance."
        }
      ];

      export default response;
