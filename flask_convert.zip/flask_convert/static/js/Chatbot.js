let responseReceived = false;

const response =
  [

    {
      "Question": "What is the purpose of a power transformer in a substation?",
      "Answer": "The primary purpose of a power transformer is to step up or step down voltage for efficient transmission and distribution of electrical power."
    },
    {
      "Question": "How does a transformer work?",
      "Answer": "Transformers work on the principle of electromagnetic induction, where varying current in one coil induces a voltage in another coil through a magnetic field."
    },
    {
      "Question": "What is the significance of the transformer nameplate information?",
      "Answer": "The nameplate provides crucial details like rated capacity, voltage, current, and cooling methods. It is essential for proper operation and maintenance."
    },
    {
      "Question": "What is a substation?",
      "Answer": "A substation is a part of an electrical generation, transmission, and distribution system. It's used to transform voltage levels, regulate power flow, and ensure safe transmission of electricity from power plants to end-users."
    },
    {
      "Question": "What are the main components of a substation?",
      "Answer": "Substations consist of various components: \nTransformers: Step-up or step-down voltage levels.\nCircuit Breakers: Protect the system by interrupting electrical currents during faults.\nBusbars: Conductor systems that distribute power within the substation.\nSwitchgear: Controls and isolates electrical equipment.\nProtection and Control Systems: Monitor and manage the substation's operation."
    },
    {
      "Question": "What is the purpose of a transformer in a substation?",
      "Answer": "Transformers in substations are crucial for voltage transformation. They either step up voltage for efficient transmission over long distances or step it down for local distribution, ensuring safe and effective electricity transfer."
    },
    {
      "Question": "Why is protection important in substations?",
      "Answer": "Protection systems safeguard equipment and personnel from electrical faults or abnormal conditions. They detect faults and isolate faulty sections to prevent widespread power outages or damage to the system."
    },
    {
      "Question": "How do substations contribute to the electrical grid?",
      "Answer": "Substations play a vital role in the electrical grid by:\nTransmitting electricity efficiently across long distances.\nDistributing power to various consumers at suitable voltage levels.\nRegulating and controlling the flow of electricity to ensure system stability."
    },
    {
      "Question": "What are the different types of substations based on functionality?",
      "Answer": "Substations can be categorized as step-up (increasing voltage for transmission), step-down (decreasing voltage for distribution), or switching (changing configurations for maintenance)."
    },
    {
      "Question": "What are the different types of power stations?",
      "Answer": "Power stations are classified based on their energy source, including coal-fired, natural gas-fired, nuclear, hydroelectric, solar, wind, and geothermal power stations."
    },
    {
      "Question": "What is the significance of power station maintenance?",
      "Answer": "Regular maintenance ensures the efficiency, reliability, and safety of power stations, reducing downtime and ensuring consistent energy supply."
    },
  ];
function handleUserQuery(userInput) {
  try {

    let botResponse = "Sorry, we didn't understand your query.";

    response.forEach(item => {
      if (userInput.toLowerCase().includes(item.Question.toLowerCase())) {
        botResponse = item.Answer;
        console.log(botResponse)
      }
    });

    return botResponse;



  } catch (error) {
    console.error('Error fetching or processing data:', error);
    return "Sorry, something went wrong. Please try again later.";
  }
}

function sendMessage() {
  const input = document.getElementById("ImageInput");
  const userInput = document.getElementById("userInput").value;


  const userI = document.getElementById("userInput").value.toLowerCase().trim();
  const matchedQuestion = response.find(item => item.Question.toLowerCase() === userI);

  var form = document.getElementById("contactForm");
  form.addEventListener("submit", function (event) {
    event.preventDefault();
  })
  if (input.files && input.files[0]) {
    let reader = new FileReader();

    reader.onload = function (e) {
      appendMessage("user", e.target.result, true);
      setTimeout(() => {
        const botResponse = "This is a bot response. You selected an image.";
        appendMessage("bot", botResponse);
      }, 500);
    }
    reader.readAsDataURL(input.files[0]);
    document.getElementById('ImageInput').value = '';

  }
  else if (matchedQuestion || userInput === "hi" || userInput==="hello" || userInput==="Hi" || userInput==="Hello" || userInput==="fire") {
    appendMessage("user", userInput, false);
    if (userInput === "hi" || userInput === "hello" || userInput==="Hi" || userInput==="Hello") {
      const botResponse = "Welcome to our site. What kind of support do you want?";
      appendMessage("bot", botResponse, false);
    }
    // else if(userInput==="fire"){
    //   const botResponse = "for more updates write email";
    //   appendMessage("bot", botResponse, false);
    // }
    else{
      setTimeout(() => {
        const botResponse = handleUserQuery(userInput);
        appendMessage("bot", botResponse, false);
      }, 500);
    }
    document.getElementById("userInput").value = "";
  }
  else {
    var query = form.elements["query"].value;
    appendMessage("user", query, false);

    // const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
    // appendBotMessage(`"How about this: " ${randomQuestion}`);

    // handleUserInputBasedOnSuggestion(randomQuestion);

    console.log(query);
    fetch('/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'query=' + encodeURIComponent(query),
    })
      .then(response => response.text())
      .then(data => {
        console.log(data);
        appendMessage("bot", data, false);
        document.getElementById("userInput").value = "";
      })
      .catch(error => console.error('Error:', error));

  }
}

function appendMessage(sender, message, isImage = false) {
  const chatBox = document.getElementById("chatBox");
  const messageDiv = document.createElement("div");
  messageDiv.classList.add(sender);

  const image = document.createElement("img");
  if (sender === "user") {
    image.src = "https://picsum.photos/200/300";
    image.alt = "User";
  } else {
    image.src = "https://picsum.photos/200/300";
    image.alt = "Bot";
  }
  image.classList.add("avatar");
  messageDiv.appendChild(image);

  if (isImage) {
    const userImage = document.createElement("img");
    userImage.src = message;
    userImage.width = 200;
    userImage.height = 100;
    userImage.alt = " ";
    messageDiv.appendChild(userImage);
  } else {
    const messageContent = document.createElement("p");
    messageContent.innerText = message;
    messageDiv.appendChild(messageContent);
  }

  chatBox.appendChild(messageDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function appendUserMessage(message) {
  appendMessage("user", message, false);
}

function appendBotMessage(message) {
  appendMessage("bot", message, false);
}

function initiateChat() {
  const chatBox = document.getElementById("chatBox");
  let isFirstInteraction = true;

  if (isFirstInteraction) {
    appendMessage("bot", "Hi there! How can we assist you with police-related inquiries today?", false);

    const relatedQuestions = [
      '1. Crime Prevention Measures',
      '2. Reporting a Crime',
      '3. Police Services',
      '4. Safety Tips for Citizens',
      '5. Traffic Regulations',
    ];

    relatedQuestions.forEach(question => {
      chatBox.innerHTML += `<div class="pre-que">${question}</div>`;
    });

    isFirstInteraction = false;
  }

  chatBox.addEventListener('click', (event) => {
    const clickedElement = event.target;
    if (clickedElement.classList.contains('pre-que')) {
      const userMessage = clickedElement.textContent;
      
      fetch('/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'query=' + encodeURIComponent(userMessage),
      })
        .then(response => response.text())
        .then(data => {
          console.log(data);
          appendMessage("bot", data, false);
          document.getElementById("userInput").value = "";
        })
        .catch(error => console.error('Error:', error));

      appendMessage("user", userMessage, false);

      if (userMessage === '1. Crime Prevention Measures') {
        appendMessage('bot', " ", false);
      }

      if (userMessage === '2. Reporting a Crime') {
        appendMessage('bot', " ", false);
        // chatBox.innerHTML += `<div class="demo">If you witness a crime or have information about one, please contact your local police department or call emergency services immediately.</div>`;
      }

      if (userMessage === '3. Police Services') {
        appendMessage('bot', " ", false);
        // const services = [
        //   '1. Emergency Response',
        //   '2. Criminal Investigation',
        //   '3. Traffic Enforcement',
        //   '4. Community Outreach Programs',
        //   '5. Victim Support Services',
        // ];
        // services.forEach(question => {
        //   chatBox.innerHTML += `<div class="pre-que">${question}</div>`;
        // });
      }

      if (userMessage === '4. Safety Tips for Citizens') {
        appendMessage('bot', " ", false);
        // chatBox.innerHTML += `<div class="demo">Here are some safety tips for citizens:
        //   <br>1. Stay alert and aware of your surroundings.
        //   <br>2. Secure your home and belongings.
        //   <br>3. Avoid walking alone in dimly lit or isolated areas.
        //   <br>4. Report suspicious activities to the authorities.
        //   <br>5. Follow traffic rules and wear seatbelts while driving.
        //   </div>`;
      }

      if (userMessage === '5. Traffic Regulations') {
        appendMessage('bot', " ", false);
        // chatBox.innerHTML += `<div class="demo">Traffic regulations are enforced to ensure road safety and smooth traffic flow. Common regulations include speed limits, lane discipline, use of seatbelts, and obeying traffic signals.</div>`;
      }
    }
  });
}

window.onload = initiateChat;


function sendDataToServer(route) {
  var checkboxes = document.querySelectorAll('.options input[type="checkbox"]');
  var selectedOptions = Array.from(checkboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.value);

  var dataToSend = { options: selectedOptions };

  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/' + route, true);
  xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');

  xhr.onload = function () {
      if (xhr.status == 200) {
          var result = JSON.parse(xhr.responseText);
          displayResult(result);
      } else {
          console.error('Error:', xhr.statusText);
      }
  };

  xhr.onerror = function () {
      console.error('Network error');
  };

  xhr.send(JSON.stringify(dataToSend));
}

function displayResult(result) {
  var chatBox = document.getElementById('chatBox');

  // Display the result text
  var resultText = document.createElement('pre');
  resultText.textContent = result.result;
  chatBox.appendChild(resultText);

  // Display selected images
  var imageInput = document.getElementById('ImageInput');
  for (var i = 0; i < imageInput.files.length; i++) {
      var imageElement = document.createElement('img');
      imageElement.src = URL.createObjectURL(imageInput.files[i]);
      chatBox.appendChild(imageElement);
  }
}